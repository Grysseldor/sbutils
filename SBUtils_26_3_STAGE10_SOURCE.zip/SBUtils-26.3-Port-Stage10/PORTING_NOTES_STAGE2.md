# SBUtils 26.3 Stage 2 — compiled? NO

The user-provided Stage 1 `build-result.txt` got as far as `:compileJava` and reported 100 javac errors (first 100 only). The Gradle and Fabric setup succeeded. Stage 2 applies source migration edits backed by Minecraft/Fabric 26.3 API documentation; **this environment has only Java 21, no external dependency downloads, and cannot run this project build**. Expect additional compiler errors and/or Mixin runtime errors.

## Changes in this pass

- Replaced `ClientCommandManager` with 26.3 `ClientCommands` in command sources.
- Replaced GUI references: `GuiGraphicsExtractor`, and `MC.gui.screen()`.
- Replaced vanilla wool item constants with block constants.
- Corrected `TextColor` conversion for legacy chat codes.
- Updated block center math to `Vec3.atCenterOf`.
- Updated sign detection to `ItemTags.SIGNS`, and packet record accessors `slot()` and `pos()`.
- Replaced the GUI render Mixin with a proposed Fabric HUD extraction callback for trader notifications.
- Updated YACL widget and enchantment screen extraction paths.
- Removed illegal `DummyPacket` subclass. Uses a null packet sentinel, which MUST be verified against current `startPrediction` internals before live use.
- Replaced `setOverlayMessage` with player actionbar display.
- Increased Javac compiler error limit to 1000 so the next build can report more incompatibilities.

## Known unresolved / MUST NOT INSTALL

1. New `HudElementRegistry` and `VanillaHudElements` imports and specific constant need verification from Gradle compiler.
2. YACL custom widget method signatures and extract invocations may differ and need compilation testing.
3. All Mixins must be verified against 26.3 actual method signatures; mixed runtime behavior may crash.
4. 26.3 sign packets and predictive use-item packet suppression need runtime testing.
5. `MapSaver` class tweaker and Map Texture code not yet migrated.
6. Other API removals are still hidden beyond the first 100 errors in Stage 1.

## Next step

Extract to a new folder on Windows, run `BUILD_AND_SAVE_LOG.bat`, and upload `build-result.txt`. Do not run this in multiplayer or place a build into your live mods folder until startup and all feature tests pass.

## Reference APIs checked

- https://docs.fabricmc.net/develop/commands/basics
- https://aldak0.ru/javadoc/26.3.x/net/minecraft/client/gui/GuiGraphicsExtractor.html
- https://aldak0.ru/javadoc/26.3.x/net/minecraft/client/gui/Gui.html
- https://aldak0.ru/javadoc/26.3.x/net/minecraft/network/chat/TextColor.html
- https://mc-packet-reference.netlify.app/26.x/source/net/minecraft/network/protocol/game/clientboundopensigneditorpacket/
- https://www.fabricmc.net/2026/09/15/263.html
