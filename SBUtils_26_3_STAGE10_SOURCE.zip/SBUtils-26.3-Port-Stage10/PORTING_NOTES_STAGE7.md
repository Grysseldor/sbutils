# SBUtils 26.3 — Stage 7: Moved raycast Mixin

## Failure recorded in user Stage 6 log

- `sbutils.mixins.json:GameRendererMixin` fails on startup when Mixin tries to target `GameRenderer.pick`.
- Target no longer exists in Minecraft 26.3.
- Stage 6 successfully initialized the configuration and created an SDL window before this failure.
- Separate HTTP 405 from `https://api.skyblock.net/staff` is a remote API failure, unrelated to this startup crash; it may affect staff detection.

## Patch

- Removed `GameRendererMixin` from the Mixin list and deleted its Java file.
- Implemented `MinecraftMixin.sbutils$autoMineRaycastFromPlayer` using `@ModifyArg` on `Minecraft.pick(F)V`, targeting the `LocalPlayer.raycastHitResult(float, Entity)` invocation and substituting the player for a free-camera entity while AutoMine is enabled.
- Preserves the Stage 6 behavior rather than disabling AutoMine.
- Incremented version to `1.3.2+26.3-port7`.

### Verification still needed

1. Compile with JDK 25: `BUILD_AND_SAVE_LOG.bat`.
2. Launch with `gradlew.bat runClient --no-daemon` in a fresh Gradle dev run.
3. If startup fails, send `run/logs/latest.log` for the next Mixin fix.
4. If startup succeeds, test the configuration screen first, then individual features. Do not treat one successful launch as proof that all features work.

### Sources

- Minecraft 26.3 `Minecraft.java`: https://mc-packet-reference.netlify.app/26.x/source/net/minecraft/client/minecraft/
- Minecraft 26.3 `GameRenderer.java`: https://mc-packet-reference.netlify.app/26.x/source/net/minecraft/client/renderer/gamerenderer/
