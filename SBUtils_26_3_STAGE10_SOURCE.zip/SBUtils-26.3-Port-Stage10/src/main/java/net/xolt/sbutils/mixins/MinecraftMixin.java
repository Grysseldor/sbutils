package net.xolt.sbutils.mixins;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.Entity;
import net.xolt.sbutils.SbUtils;
import net.xolt.sbutils.config.ModConfig;
import net.xolt.sbutils.feature.features.InvCleaner;
import net.xolt.sbutils.feature.features.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Minecraft.class)
public abstract class MinecraftMixin {
    @Shadow public int missTime;

    @Shadow
    protected abstract void continueAttack(boolean breaking);

    @Inject(method = "tick", at = @At("HEAD"))
    private void onTick(CallbackInfo ci) {
        SbUtils.FEATURES.get(EnchantAll.class).tick();
        SbUtils.FEATURES.get(AutoAdvert.class).tick();
        SbUtils.FEATURES.get(JoinCommands.class).tick();
        SbUtils.FEATURES.get(AutoCrate.class).tick();
        SbUtils.FEATURES.get(AutoSilk.class).tick();
        SbUtils.FEATURES.get(AutoFix.class).tick();
        SbUtils.FEATURES.get(AutoRaffle.class).tick();
        SbUtils.FEATURES.get(AutoReply.class).tick();
        SbUtils.FEATURES.get(AutoCommand.class).tick();
        SbUtils.FEATURES.get(AutoKit.class).tick();
        SbUtils.FEATURES.get(InvCleaner.class).tick();
        SbUtils.FEATURES.get(Notifier.class).tick();
        SbUtils.COMMAND_SENDER.tick();
    }

    @Inject(method = "tick", at = @At("TAIL"))
    private void onTickTail(CallbackInfo ci) {
        SbUtils.FEATURES.get(AutoMine.class).tick();
        // Minecraft 26.3 moved the current screen and overlay into Gui.
        Minecraft minecraft = (Minecraft) (Object) this;
        if (ModConfig.instance().autoMine.enabled && AutoMine.shouldMine()
                && (minecraft.gui.screen() != null || minecraft.gui.overlay() != null)) {
            missTime = 0;
            continueAttack(true);
        }
    }

    // Minecraft 26.3 moved block/entity selection out of GameRenderer.pick
    // and into Minecraft.pick(float). Preserve the original SBUtils AutoMine
    // free-camera handling by changing the raycast's camera-entity argument.
    @ModifyArg(
            method = "pick(F)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/player/LocalPlayer;raycastHitResult(FLnet/minecraft/world/entity/Entity;)Lnet/minecraft/world/phys/HitResult;"
            ),
            index = 1
    )
    private Entity sbutils$autoMineRaycastFromPlayer(Entity cameraEntity) {
        Minecraft minecraft = (Minecraft) (Object) this;
        if (minecraft.player != null && ModConfig.instance().autoMine.enabled
                && cameraEntity != minecraft.player) {
            return minecraft.player;
        }
        return cameraEntity;
    }

    @Inject(method = "continueAttack", at = @At("HEAD"), cancellable = true)
    public void onHandleBlockBreaking(boolean breaking, CallbackInfo ci) {
        SbUtils.FEATURES.get(ToolSaver.class).onContinueAttack(breaking, ci);
    }

    @Inject(method = "startAttack", at = @At("HEAD"), cancellable = true)
    public void onDoAttack(CallbackInfoReturnable<Boolean> cir) {
        SbUtils.FEATURES.get(ToolSaver.class).onStartAttack(cir);
    }
}
