package net.xolt.sbutils.mixins;

import net.xolt.sbutils.feature.features.Mentions;
import net.xolt.sbutils.feature.features.NoGMT;
import net.xolt.sbutils.feature.features.Notifier;
import net.minecraft.client.gui.components.ChatComponent;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(ChatComponent.class)
public abstract class ChatComponentMixin {

    // Minecraft 26.3: ChatComponent.addMessage now accepts GuiMessageSource and
    // uses the net.minecraft.client.multiplayer.chat message classes.
    // Modify the incoming Component directly to avoid depending on the old
    // GuiMessage constructor/invocation target.
    @ModifyVariable(
            method = "addMessage(Lnet/minecraft/network/chat/Component;Lnet/minecraft/network/chat/MessageSignature;Lnet/minecraft/client/multiplayer/chat/GuiMessageSource;Lnet/minecraft/client/multiplayer/chat/GuiMessageTag;)V",
            at = @At("HEAD"),
            argsOnly = true,
            ordinal = 0
    )
    private Component sbutils$modifyIncomingMessage(Component component) {
        return sbutils$modifyChatMessage(component);
    }

    @Unique
    private Component sbutils$modifyChatMessage(Component component) {
        Component result = Mentions.modifyMessage(component);
        result = NoGMT.modifyMessage(result);
        result = Notifier.modifyMessage(result);
        return result;
    }
}
