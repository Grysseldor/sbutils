# SBUtils 26.3 Port — Stage 7 (EXPERIMENTAL)

This is a **source project**, not a finished Minecraft mod.

1. Requires Java JDK 25 on Windows and Internet access for Maven dependencies.
2. Double-click `BUILD_AND_SAVE_LOG.bat`.
3. Upload the generated `build-result.txt` back into this conversation.
4. **Do not install a JAR into your main game profile until runtime Mixins and features are tested.**

Current code fixes are based on Minecraft 26.3 sources and on the user's Stage 2 compile log. They have not been compiled in this container, which lacks JDK 25 and network access to Gradle repositories.

For a `BUILD SUCCESSFUL` result, check `build/libs/` for the JAR. Compile success alone does not guarantee that all Mixins work in-game.

## Stage 7 status

Stage 6 reached Minecraft's SDL window initialization, then crashed because `GameRendererMixin` targeted a removed `GameRenderer.pick` method. Stage 7 moves the AutoMine raycast camera override into `MinecraftMixin` to target Minecraft 26.3's `Minecraft.pick(float)` call to `LocalPlayer.raycastHitResult`.

**Not compiled or runtime validated here.** Run `BUILD_AND_SAVE_LOG.bat`, then `gradlew.bat runClient --no-daemon`. If it fails, upload `run\logs\latest.log`. Do not install this build in your normal game instance before validation.
