# Stage 3 fixes, 2026-10-21

Based on 27 compile errors in Stage 2 log. Updated:

- `ModConfig`: moved colored wool kit entries to `Items.WOOL.pick(DyeColor.XXX)` (26.3 ColorCollection).
- `AutoPrivate`: corrected front-sign slot predicate and `ServerboundSignUpdatePacket(BlockPos, List<String>, SignTextSlot)` constructor.
- `AutoReply`: used `LocalPlayer.sendOverlayMessage`.
- `ChatUtils`: used `LocalPlayer.sendSystemMessage`; moved titles to `Gui.hud`.
- Class tweaker: allowed `net.minecraft.client.gui.Gui#hud` to be accessed for title rendering.
- `CommandAliases`: replaced legacy `ItemInput.getItem()` with `item.item().value()` (Holder).
- `FileUtils`: used desktop opening API; guarded unsupported/headless environments.
- `TextUtils`: replaced removed `ChatFormatting.getColor()` with standard legacy hex RGB for green and red.

This project **requires a new Gradle build and a runtime validation pass**. In particular, the new class tweaker field descriptor and Mixins still need validation on Minecraft 26.3.
