# SBUtils 26.3 — Stage 9: Invalid SDL keybinding fix

## Crash report
User's October 21, 2026 crash reached the Skyblock.net overworld, then failed in `InputConstants.isKeyDown` -> `KeyMapping.setAll` -> `MouseHandler.grabMouse` while the level-loading screen was closing.

## Root cause found in SBUtils source
Previous SBUtils builds registered seven intentionally-unbound shortcuts with the old GLFW convention `-1` in `SbUtils.registerKeybindings()`. Minecraft 26.3 uses SDL scancodes and `InputConstants.UNKNOWN.getValue() == 0` for an unbound key. The negative value was eligible for `KeyMapping.setAll`, which calls `InputConstants.isKeyDown(value)` and can index outside SDL's keyboard state buffer.

## Changes
- Set defaults for island, ehome, jump, back, craft, echest and trash to `InputConstants.UNKNOWN.getValue()` (0).
- Added a one-time migration on the first client tick: any persisted negative keyboard code on SBUtils key mappings is changed to `InputConstants.UNKNOWN`, key lookup is rebuilt and Minecraft options are saved. This preserves any other valid custom bindings.
- Bumped version to `1.3.2+26.3-port9`.

## Tests
1. Build via `BUILD_AND_SAVE_LOG.bat` using JDK 25; verify `BUILD SUCCESSFUL`.
2. Remove older SBUtils JAR and install the compiled Stage 9 JAR in the 26.3 Fabric profile (do not use the `-sources` or `-dev` artifacts).
3. Launch and spend several seconds on the main menu before joining Skyblock.net (allows one-time migration).
4. If connection still fails, copy the new crash report and `logs/latest.log`. Compare once without SBUtils on a separate test profile to isolate possible interactions with other mods.
5. After connection, verify movement and shortcuts; keep automation disabled until separately tested.

## Limitations
Source-only patch; not compiled or runtime-tested in the assistant environment (Java 21 only). Other mods may register invalid bindings too; this patch sanitizes only SBUtils shortcuts.

Code references: Minecraft 26.3 KeyMapping.shouldSetOnIngameFocus, KeyMapping.setAll, and InputConstants.UNKNOWN in the official-mapped source at mc-packet-reference.netlify.app.
