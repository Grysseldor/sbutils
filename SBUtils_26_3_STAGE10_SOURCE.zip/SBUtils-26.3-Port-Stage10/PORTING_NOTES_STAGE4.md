# SBUtils Minecraft 26.3 — Stage 4

## Fix

A successful Stage 3 compilation failed when the Minecraft client started because `MinecraftMixin` declared `@Shadow Screen screen`. Minecraft 26.3 no longer has `Minecraft.screen`; the active screen is obtained using `Minecraft.gui.screen()`. The old `Minecraft.overlay` shadow was also removed in favor of `Minecraft.gui.overlay()`. This change keeps the existing AutoMine behavior while avoiding nonexistent shadows.

## Validate

On Windows with Java 25:

1. In this project's directory, run `BUILD_AND_SAVE_LOG.bat` (or `gradlew.bat build --no-daemon`).
2. If the build succeeds, run `gradlew.bat runClient --no-daemon` from the same directory.
3. If Minecraft crashes, upload `run/logs/latest.log`. Also inspect the most recent `run/crash-reports/*.txt` if generated.
4. If Minecraft opens, test configuration and features offline/in a safe environment before use on the server.

This project has not been compiled or runtime-tested in the assistant environment (which has Java 21, not 25). Expect other Mixins may still need updating.
