# SBUtils Minecraft 26.3 — Stage 5

## Diagnosis from Stage 4 `latest.log`

Fabric successfully loads SBUtils and the former `MinecraftMixin` shadow crash does not recur.
YACL reports `ExceptionInInitializerError: Components not bound yet`, caused by
`ModConfig$SkyblockKit.<clinit>` constructing `new ItemStack(...)` while Minecraft's
item registry has not finished binding components. This prevents reliable config loading.

## Fix

`ModConfig.java` now uses `Supplier<List<ItemStack>>` for SkyblockKit, EconomyKit,
and ClassicKit item templates. The actual item stacks are constructed lazily on the
first `getItems()` call (typically after a player joins). Derived kit enums use
method references instead of accessing/evaluating the original kit's item lists
during static enum initialization. All kit names, cooldowns and item counts are retained.

No feature was intentionally disabled. The compile + runtime effects still need verification.

## Test on Windows (Java 25)

1. Extract the Stage 5 ZIP to its own new folder, not inside Stage 4.
2. Run `BUILD_AND_SAVE_LOG.bat` (or `gradlew.bat build --no-daemon`).
3. In the same folder run `gradlew.bat runClient --no-daemon`.
4. If Minecraft opens, check the Mod Menu > SBUtils settings and that default kit config loads without error.
5. If a failure occurs upload `run/logs/latest.log`, plus any `run/crash-reports/*.txt` generated.

Gradle's `runClient` in this development environment uses an offline test account
(`Player###`); a Minecraft authentication 401 warning is unrelated to this config error.
Do not copy the experimental JAR into your main Minecraft profile before runtime testing.
