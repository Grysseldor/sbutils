# SBUtils 26.3 — Stage 8: Multiplayer join fix

## Crash evidence

User disconnect report from 2026-10-21 03:43:14: `MultiPlayerGameModeMixin` attempts to inject into nonexistent `method_41933`, causing a Mixin transformation failure while the Minecraft login packet is processed.

## Changes

- Removed the obsolete `method_41933` injection in `MultiPlayerGameModeMixin`. Its purpose was to cancel a prediction packet when SBUtils AntiPlace/ToolSaver rejects a placement.
- Preserved blocked-placement packet suppression using a field set by `performUseItemOn` on a null return. The existing `startPrediction` injection aborts packet sending in that case.
- Updated the ToolSaver entity-interaction injection to the actual 26.3 `interact(Player, Entity, EntityHitResult, InteractionHand)` signature. Removed `interactAt`, which no longer exists in 26.3.
- Updated the mod version to `1.3.2+26.3-port8`.

## Verification required

1. Compile Stage 8 with JDK 25 via `BUILD_AND_SAVE_LOG.bat`.
2. Install built JAR in a disposable Fabric 26.3 instance and test connecting to a server; a dev-client launch without an authenticated account is insufficient for this test.
3. If disconnected, upload a new `disconnect-*.txt` or `latest.log`. If it reaches the server, test ordinary chat and inventory before enabling automated functions.
4. Test blocked placing of named heads and grass with AntiPlace only in a safe environment, then ToolSaver with an expendable damaged tool.

## Limitations

Source ZIP integrity is checked, not compiled or runtime tested by the assistant. The Minecraft 26.3 user environment has JDK 25 and remains the build/test environment. Additional Mixins may fail only when an in-game feature first loads.

Source checked: https://mc-packet-reference.netlify.app/26.x/source/net/minecraft/client/multiplayer/multiplayergamemode/
