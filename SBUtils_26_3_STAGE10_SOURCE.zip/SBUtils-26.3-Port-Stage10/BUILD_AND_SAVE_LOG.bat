@echo off
setlocal
cd /d "%~dp0"
echo Checking Java...
java -version
if errorlevel 1 (
 echo Java not found. Install JDK 25 and add it to PATH.
 pause
 exit /b 1
)
echo.
echo Building SBUtils 26.3 Stage 10 source project...
echo This build checks the Stage 10 SDL keybinding migration fix. Save the full log.
echo.
call gradlew.bat build --stacktrace --no-daemon --console=plain > build-result.txt 2>&1
set RESULT=%ERRORLEVEL%
echo.
echo Exit code: %RESULT%
echo Build log: "%~dp0build-result.txt"
echo.
if not "%RESULT%"=="0" (
 echo The build FAILED. Upload build-result.txt for the next porting step.
) else (
 echo Build SUCCEEDED. Next validate Mixins by running the Minecraft dev client.
)
explorer.exe "%~dp0"
pause
exit /b %RESULT%
