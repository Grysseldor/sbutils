# SBUtils → Minecraft 26.3: Stage 1 source port

**Status: NOT YET COMPILED OR TESTED. This ZIP is a development project, NOT an installable mod.**

This experimental source port is based on the user-supplied SBUtils repository archive,
which contains Java source for Minecraft 1.21.11, not just 1.20.4.
The upstream GPL-3.0 license and authorship are preserved (see `LICENSE` and
`README_UPSTREAM.md`). No auction scanner or automatic auction-buying has been added.

## Confirmed environment

- Minecraft Java Edition **26.3**
- **JDK 25**, not JDK 21. JDK 25 must be used by Gradle.
- Fabric Loader **0.19.5** and Fabric API **0.163.0+26.3**
- Fabric Loom **1.17-SNAPSHOT** (non-remapping), Gradle **9.6.0**
- Mod Menu **21.0.0** and YACL **3.9.6+26.3-fabric**
- exp4j **0.4.8** (bundled by Loom's include configuration)

These versions were checked against Fabric's 26.3 migration announcement and
mod projects targeting the same Minecraft version. If dependency resolution fails,
check the published Maven version and adjust `gradle.properties`.

## Windows build instructions

1. Install **JDK 25** and ensure that `java -version` reports **25**, not 21.
   Set `JAVA_HOME` to the JDK 25 installation directory if necessary.
2. Extract this ZIP to a path without spaces, e.g. `C:\MCDev\SBUtils263`.
3. Double-click **BUILD_AND_SAVE_LOG.bat**. The script runs Gradle `build`, records
   the full console output in `build-result.txt`, and opens the output directory.
4. If the compiler fails (EXPECTED in Stage 1), upload `build-result.txt`
   to ChatGPT so we can repair the exact remaining API errors.
5. After compilation succeeds, run `gradlew.bat validateAccessWidener`, then
   `gradlew.bat runClient` and verify startup and all 15 Mixins.
6. Install **only a successfully built and tested** `build/libs/sbutils-...jar` into
   a Minecraft **26.3 Fabric** profile, along with matching Fabric API + YACL.
   Do not install the `-sources.jar` artifact.

## Changes already made

- Removed Stonecutter for this **26.3-only copy**; preserved all upstream Java files.
- Replaced legacy Loom remapping plugin with `net.fabricmc.fabric-loom`.
- Updated Gradle and Java target to 9.6 and Java 25.
- Replaced `fabric` dependency with `fabric-api` and set the Minecraft 26.3 target.
- Replaced the legacy access widener with a provisional official-name class tweaker.
- Migrated keybind registration to `KeyMappingHelper`, SDL scancodes and `KEYBOARD`.
- Migrated inventory clicks to `handleContainerInput` / `ContainerInput`.
- Migrated Minecraft screen opening to `MC.gui.setScreen(...)`.
- Updated Mixin compatibility level to `JAVA_25`.

## Expected remaining blockers

1. Changes to `GuiGraphics` rendering, especially `GuiMixin`, `Notifier` and YACL screens.
2. Some Minecraft methods and fields have changed or moved between 1.21.11 and 26.3.
3. Custom `MapSaver` uses a widened MapTextureManager method that may no longer exist.
4. 15 Mixin targets, method names, descriptors and injection points require validation.
5. 26.3 SDL `MouseButtonEvent` / `KeyEvent` signatures and YACL 3.9.6 controllers.
6. Gradle coordinates and `modmenu` + `yacl` integration must be resolved online.

**Important:** Do not rename this source ZIP to `.jar` or place it in the Minecraft
mods directory. We cannot call this port finished until it compiles and starts.

Sources:
- https://fabricmc.net/2026/09/15/263.html
- https://fabricmc.net/2026/03/14/261.html
- https://docs.fabricmc.net/develop/class-tweakers/
