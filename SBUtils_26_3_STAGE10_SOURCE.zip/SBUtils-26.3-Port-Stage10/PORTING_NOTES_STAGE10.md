# SBUtils 26.3 — Stage 10: Fix Stage 9 keybinding compilation errors

## Evidence
Stage 9 build-result(3).txt reported two errors in `SbUtils.java` lines 175–176: `KeyMapping.getKey()` cannot be resolved. All earlier compilation error groups from Stages 1–8 were cleared.

## Fix
- Replace both calls to `binding.getKey()` in the Stage 9 migration loop with `KeyMappingHelper.getBoundKeyOf(binding)`.
- `getBoundKeyOf` is the existing Fabric API accessor for a key mapping's configured `InputConstants.Key`, and `KeyMappingHelper` was already imported and used elsewhere in `SbUtils.java`.
- The migration logic, the 0-code default shortcuts, and the Stage 8 multiplayer Mixin updates are otherwise unchanged.
- Bump mod version to `1.3.2+26.3-port10`.

## Verification status
Source and ZIP checked. Needs compilation using Java 25 on Windows, followed by actual server connection testing; the assistant environment has Java 21. The previous Stage 8 report included other installed mods, so a further crash could involve another mod's keybinding.

## Build and test
1. Extract in a separate folder and double-click `BUILD_AND_SAVE_LOG.bat`.
2. Confirm `BUILD SUCCESSFUL`. If not, upload `build-result.txt`.
3. In `build/libs/`, install the normal SBUtils JAR (not `-sources.jar` or `-dev.jar`), remove previous SBUtils JARs, and launch Fabric 26.3.
4. Attempt Skyblock.net connection. If crash persists, upload crash report and `latest.log`; compare with a clean profile containing only SBUtils and required dependencies to rule out conflicts.
