plugins {
    id("net.fabricmc.fabric-loom") version "1.17-SNAPSHOT"
    id("maven-publish")
}

version = property("mod_version") as String
base.archivesName.set("sbutils")
group = property("mod_group") as String

repositories {
    maven("https://maven.isxander.dev/releases") { name = "isXander" }
    maven("https://maven.terraformersmc.com/") { name = "TerraformersMC" }
    mavenCentral()
}

dependencies {
    // In Minecraft 26.1+ Mojang ships unobfuscated jars: no mappings or remap configurations.
    minecraft("com.mojang:minecraft:${property("minecraft_version")}")
    implementation("net.fabricmc:fabric-loader:${property("loader_version")}")
    implementation("net.fabricmc.fabric-api:fabric-api:${property("fabric_version")}")
    implementation("com.terraformersmc:modmenu:${property("modmenu_version")}")
    implementation("dev.isxander:yet-another-config-lib:${property("yacl_version")}")
    implementation("net.objecthunter:exp4j:${property("exp4j_version")}")
    include("net.objecthunter:exp4j:${property("exp4j_version")}")
}

loom {
    accessWidenerPath = file("src/main/resources/sbutils.classtweaker")
}

java {
    toolchain.languageVersion.set(JavaLanguageVersion.of(25))
    withSourcesJar()
}

tasks.withType<JavaCompile>().configureEach {
    options.release.set(25)
    // Show the actual error count rather than stopping at Javac's default 100 errors.
    options.compilerArgs.add("-Xmaxerrs")
    options.compilerArgs.add("1000")
}

tasks.processResources {
    val modVersion = project.version.toString()
    inputs.property("version", modVersion)
    filesMatching("fabric.mod.json") {
        expand(mapOf("version" to modVersion))
    }
}
